<?php
/**
 * Connects to the database.
 * Return false if connection failed.
 * Be sure to change the $database_name. $database_username , and 
 * $database_password values  to reflect your database settings.
 */
function db_connect() {
  $database_name = 'mysql'; // Set this to your Database Name
  $database_username = 'root'; // Set this to your MySQL username
  $database_password = ''; // Set this to your MySQL password
  $result = mysql_pconnect('localhost',$database_username, $database_password); 
  if (!$result) return false;
  if (!mysql_select_db($database_name)) return false;
  return $result;
}
$conn = db_connect(); // Connect to database
if ($conn) {
  $zipcode = $_GET['param']; // The parameter passed to us
  $query = "select * from zipcodes where zipcode = '$zipcode'";
  $result = mysql_query($query,$conn);
  $count = mysql_num_rows($result);
  if ($count > 0) {
    $city = mysql_result($result,0,'city');
	$state = mysql_result($result,0,'state');
  }
}
if (isset($city) && isset($state)) { 
  $return_value = $city . "," . $state; 
}
else {  
  $return_value = "invalid".",".$_GET['param']; // Include Zip for debugging purposes
}
echo $return_value; // This will become the response value for the XMLHttpRequest object
?>