#
# Table structure for table `zipcodes`
#

CREATE TABLE `zipcodes` (
  `zipcode` mediumint(9) NOT NULL default '0',
  `city` tinytext NOT NULL,
  `state` char(2) NOT NULL default '',
  `areacode` smallint(6) NOT NULL default '0',
  PRIMARY KEY  (`zipcode`),
  UNIQUE KEY `zipcode_2` (`zipcode`),
  KEY `zipcode` (`zipcode`)
) TYPE=MyISAM;
